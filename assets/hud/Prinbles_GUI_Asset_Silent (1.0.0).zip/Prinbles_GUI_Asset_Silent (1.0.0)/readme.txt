Hello!

See the "fonts.txt" file for information about fonts used in the asset.
Open the "THANK YOU! - README.html" in your browser.

Folders description:
"/asset/@previews" – handy previews of all contained sprites
"asset/png" – sprites in raster PNG format
"asset/png@2x" – sprites twice as big 
"asset/png@3x" – 3x bigger
"asset/svg" – sprites in vector SVG format

Good luck!